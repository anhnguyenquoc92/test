package com.example.demo.dto;

import java.util.List;

import org.springframework.http.HttpStatus;

import com.example.demo.exception.bookexception.BusinessErrorCode;

public class ApiError {
	String message;
	List<String> details;
	BusinessErrorCode businessQueryErrorCode;
	HttpStatus httpStatus;

	public ApiError(String message, List<String> details, BusinessErrorCode businessQueryErrorCode,
			HttpStatus httpStatus) {
		super();
		this.message = message;
		this.details = details;
		this.businessQueryErrorCode = businessQueryErrorCode;
		this.httpStatus = httpStatus;
	}

	public ApiError(String message, List<String> details) {
		super();
		this.message = message;
		this.details = details;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<String> getDetails() {
		return details;
	}

	public void setDetails(List<String> details) {
		this.details = details;
	}

	public BusinessErrorCode getBusinessQueryErrorCode() {
		return businessQueryErrorCode;
	}

	public void setBusinessQueryErrorCode(BusinessErrorCode businessQueryErrorCode) {
		this.businessQueryErrorCode = businessQueryErrorCode;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}
}
