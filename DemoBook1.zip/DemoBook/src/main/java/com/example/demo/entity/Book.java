package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "book", schema = "bookdatabase")
public class Book {
	@Id
	@Column(name = "uid", nullable = false)
	@NotNull(message = "BookId should not be empty")
	int uid;

	@Column(name = "code", nullable = false)
	@NotEmpty(message = "BookId should not be empty")
	@Size(max = 20, message = "Size of code should not be greater than 20")
	String code;

	@Column(name = "name", nullable = false)
	@NotEmpty(message = "Name should not be empty")
	@Size(max = 255, message = "Size of name should not be greater than 255")
	String name;

	@Column(name = "description")
	@Size(max = 500, message = "Size of description should not be greate than 500")
	String description;

	@Column(name = "category", nullable = false)
	@NotEmpty(message = "Category should not be empty")
	@Size(max = 255, message = "Size of category should not be greater than 255")
	String category;

	@Column(name = "author", nullable = false)
	@NotEmpty(message = "Author should not be empty")
	@Size(max = 255, message = "Size of author should not be greater than 255")
	String author;

	@Column(name = "publisher")
	@Size(max = 255, message = "Size of publisher should not be greater than 255")
	String publisher;

	@Column(name = "create_user", nullable = false)
	@NotNull(message = "Create User should not be empty")
	@Size(max = 255, message = "Size of create user should not be greater than 100")
	String createUser;

	@Column(name = "create_date", nullable = false)
	@NotEmpty(message = "Create date should not be empty")
	@Size(max = 255, message = "Size of create date should not be greater than 100")
	String createDate;

	@Column(name = "update_user", nullable = false)
	@NotEmpty(message = "Update user should not be empty")
	@Size(max = 255, message = "Size of update user should not be greater than 100")
	String updateUser;

	@Column(name = "update_date")
	@NotEmpty(message = "Update date should not be empty")
	@Size(max = 255, message = "Size of update date should not be greater than 100")
	String updateDate;

	public Book(int uid, String code, String name, String description, String category, String author, String publisher,
			String createUser, String createDate, String updateUser, String updateDate) {
		super();
		this.uid = uid;
		this.code = code;
		this.name = name;
		this.description = description;
		this.category = category;
		this.author = author;
		this.publisher = publisher;
		this.createUser = createUser;
		this.createDate = createDate;
		this.updateUser = updateUser;
		this.updateDate = updateDate;
	}

	public Book() {
		super();
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
}
