package com.example.demo.exception.bookexception;

import org.springframework.http.HttpStatus;

public class BookBusinessException extends RuntimeException {
  private static final long serialVersionUID = 2237164598124433306L;
  protected BusinessErrorCode businessErrorQueryCode;
  protected HttpStatus httpStatus;

  public BookBusinessException(String message, BusinessErrorCode businessErrorQueryCode,
      HttpStatus httpStatus) {
    super(message);
    this.businessErrorQueryCode = businessErrorQueryCode;
    this.httpStatus = httpStatus;
  }

  public BookBusinessException(String message) {
    super(message);
    this.businessErrorQueryCode = BusinessErrorCode.BookNotFound;
    this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
  }

  public BusinessErrorCode getBusinessErrorQueryCode() {
    return businessErrorQueryCode;
  }

  public void setBusinessErrorQueryCode(BusinessErrorCode businessErrorQueryCode) {
    this.businessErrorQueryCode = businessErrorQueryCode;
  }

  public HttpStatus getHttpStatus() {
    return httpStatus;
  }

  public void setHttpStatus(HttpStatus httpStatus) {
    this.httpStatus = httpStatus;
  }
}
