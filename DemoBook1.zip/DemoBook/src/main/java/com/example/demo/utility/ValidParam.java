package com.example.demo.utility;

import java.util.List;

import com.example.demo.entity.Book;
import com.example.demo.exception.bookexception.DuplicateBookIdException;
import com.example.demo.exception.bookexception.DuplicateCodeException;
import com.example.demo.exception.bookexception.ValidParamException;

public class ValidParam {
  public static void checkUniqueCode(List<String> codes, String code) {
    if (codes.contains(code)) {
      throw new DuplicateCodeException("Code should be unique");
    }
  }

  public static void checkUniqueBookId(List<Integer> bookIds, int bookId) {
    if (bookIds.contains(bookId)) {
      throw new DuplicateBookIdException("BookId should be unique");
    }
  }

//  public static void checkSizeParamOfBook(Book book) {
//    if (book.getCode().length() > 20) {
//      throw new ValidParamException("Size of code should be less than 20");
//    } else if (book.getCode().isEmpty()) {
//      throw new ValidParamException("Code should not be null");
//    }
//
//    if (book.getName().length() > 255) {
//      throw new ValidParamException("Size of name should be less than 255");
//    } else if (book.getName().isEmpty()) {
//      throw new ValidParamException("Name should not be null");
//    }
//
//    if (book.getCategory().length() > 255) {
//      throw new ValidParamException("Size of category should be less than 255");
//    } else if (book.getCategory().isEmpty()) {
//      throw new ValidParamException("Category should not be null");
//    }
//
//    if (book.getAuthor().length() > 255) {
//      throw new ValidParamException("Size of author should be less than 255");
//    } else if (book.getAuthor().isEmpty()) {
//      throw new ValidParamException("Author should not be null");
//    }
//
//    if (book.getCreateUser().length() > 255) {
//      throw new ValidParamException("Size of create user should be less than 255");
//    } else if (book.getCreateUser().isEmpty()) {
//      throw new ValidParamException("Create user should not be null");
//    }
//
//    if (book.getCreateDate().length() > 255) {
//      throw new ValidParamException("Size of create date should be less than 255");
//    } else if (book.getCreateDate().isEmpty()) {
//      throw new ValidParamException("Create date should not be null");
//    }
//
//    if (book.getUpdateUser().length() > 255) {
//      throw new ValidParamException("Size of update user should be less than 255");
//    } else if (book.getUpdateUser().isEmpty()) {
//      throw new ValidParamException("Update user should not be null");
//    }
//
//    if (book.getUpdateDate().length() > 255) {
//      throw new ValidParamException("Size of update date should be less than 255");
//    } else if (book.getUpdateDate().isEmpty()) {
//      throw new ValidParamException("Update date should not be null");
//    }
//  }

  public static void validBookId(int bookId) {
    if (bookId < 1) {
      throw new ValidParamException("Book id should be greater than 1");
    }
  }
}
